using UnityEngine;
using UnityEngine.InputSystem;


public class player : MonoBehaviour
{
    //�⺻ ����
    [SerializeField]
    private Collider collider;
    [SerializeField]
    private Rigidbody rb;
    [SerializeField]
    private bool isGround = false;
    [SerializeField]
    private int jumpCount;
    [SerializeField]
    private Animator animator;
   

    public float speed;
    public float jumpHigh;
    public float rotationspeed;
    public float rotation;
    public float Gravity;
    
    void Start()
    {
        speed = 300;
        jumpCount = 0;
        jumpHigh = 100;
        rotationspeed = 30;
        Gravity = 0.2f;
        
    }

    private void FixedUpdate()
    {
        
        
            // �̵� ���� 
            Vector3 dir = Vector3.zero;
            dir += Vector3.down * Gravity;

            if (Keyboard.current.wKey.isPressed)
                dir += Vector3.forward;
            animator.SetFloat("canWalk", dir.magnitude);
            if (Keyboard.current.sKey.isPressed)
                dir += Vector3.back;
            animator.SetFloat("canWalk", dir.magnitude);
            if (Keyboard.current.aKey.isPressed)
                dir += Vector3.left;
            animator.SetFloat("canWalk", dir.magnitude);
            if (Keyboard.current.dKey.isPressed)
                dir += Vector3.right;
            animator.SetFloat("canWalk", dir.magnitude);



            dir = transform.TransformDirection(dir);


            rb.linearVelocity = dir * speed * Time.deltaTime;
            dir.Normalize();
            

        // ���� ȸ�� ����
        if (Keyboard.current.eKey.isPressed)
        {
            rotation += Time.fixedDeltaTime * rotationspeed;
            transform.rotation = Quaternion.Euler(0, rotation, 0);
        }
        if (Keyboard.current.qKey.isPressed)
        {
            rotation -= Time.fixedDeltaTime * rotationspeed;
            transform.rotation = Quaternion.Euler(0, rotation, 0);
        }

       
        
            if (Keyboard.current.spaceKey.wasPressedThisFrame)
            {
                if (isGround == true)
                {
                    rb.AddForce(Vector3.up * jumpHigh, ForceMode.Impulse);
                    jumpCount++;
                    animator.SetTrigger("jump");
                }
                if (jumpCount == 2)
                {
                    isGround = false;
                }

            }

        //�ִϸ��̼� ������ ����� ���ؼ� �̸��� ��� �ͼ� ���,magnitude �̰��� ������ �ƴ� ũ�⸸�� ������ ���ڴٴ� ��
        
        animator.SetBool("isJump", true);
        animator.SetBool("isFall", false);
        if(transform.position.y<=-1)
        {
            animator.SetBool("isFall", true);
            animator.SetTrigger("fall");
        }
    }
    
    
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag =="Ground")
        { 
            isGround = true;
            jumpCount = 0;
            animator.SetBool("isJump", false);
        }
    }
}
